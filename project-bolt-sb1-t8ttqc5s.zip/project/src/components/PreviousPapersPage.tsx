import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Subject, QuestionPaper } from '../lib/database.types';
import { FileText, Clock, Award } from 'lucide-react';

export function PreviousPapersPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [papers, setPapers] = useState<QuestionPaper[]>([]);
  const [selectedPaper, setSelectedPaper] = useState<QuestionPaper | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubjects();
  }, []);

  useEffect(() => {
    if (selectedSubject) {
      loadPapers(selectedSubject);
    }
  }, [selectedSubject]);

  async function loadSubjects() {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name');

      if (error) throw error;
      setSubjects(data || []);
    } catch (error) {
      console.error('Error loading subjects:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadPapers(subjectId: string) {
    try {
      const { data, error } = await supabase
        .from('question_papers')
        .select('*')
        .eq('subject_id', subjectId)
        .order('year', { ascending: false });

      if (error) throw error;
      setPapers(data || []);
    } catch (error) {
      console.error('Error loading papers:', error);
    }
  }

  const selectedSubjectData = subjects.find(s => s.id === selectedSubject);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Previous Year Question Papers</h2>
        <p className="text-gray-600">Practice with authentic CBSE board exam papers</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Subject</h3>
            <div className="space-y-2">
              {subjects.map((subject) => (
                <button
                  key={subject.id}
                  onClick={() => {
                    setSelectedSubject(subject.id);
                    setSelectedPaper(null);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedSubject === subject.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {subject.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          {!selectedSubject ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Select a subject to view question papers</p>
            </div>
          ) : selectedPaper ? (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <button
                  onClick={() => setSelectedPaper(null)}
                  className="text-blue-600 hover:text-blue-700 mb-4 text-sm font-medium"
                >
                  Back to papers
                </button>

                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{selectedPaper.title}</h3>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{selectedPaper.duration} minutes</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Award className="w-4 h-4" />
                      <span>{selectedPaper.total_marks} marks</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <FileText className="w-4 h-4" />
                      <span className="capitalize">{selectedPaper.exam_type.replace('_', ' ')}</span>
                    </div>
                  </div>
                </div>

                <div className="prose prose-sm max-w-none">
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 whitespace-pre-wrap">
                    {selectedPaper.paper_content}
                  </div>
                </div>
              </div>
            </div>
          ) : papers.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No question papers available for {selectedSubjectData?.name} yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-white rounded-lg shadow-md p-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  {selectedSubjectData?.name} - {papers.length} Papers
                </h3>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {papers.map((paper) => (
                  <div
                    key={paper.id}
                    className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => setSelectedPaper(paper)}
                  >
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="text-lg font-semibold text-gray-900 mb-2">{paper.title}</h4>
                          <div className="flex flex-wrap gap-3 text-sm text-gray-600">
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>{paper.duration} min</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Award className="w-4 h-4" />
                              <span>{paper.total_marks} marks</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end space-y-2">
                          <span className="text-2xl font-bold text-blue-600">{paper.year}</span>
                          <span className="px-3 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 capitalize">
                            {paper.exam_type.replace('_', ' ')}
                          </span>
                        </div>
                      </div>

                      <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium text-sm mt-4">
                        <FileText className="w-4 h-4" />
                        <span>View Paper</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
