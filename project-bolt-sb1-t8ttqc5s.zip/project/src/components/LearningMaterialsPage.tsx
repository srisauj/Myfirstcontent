import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Subject, Topic, LearningMaterial } from '../lib/database.types';
import { BookOpen, ChevronRight, FileText } from 'lucide-react';

export function LearningMaterialsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [materials, setMaterials] = useState<LearningMaterial[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubjects();
  }, []);

  useEffect(() => {
    if (selectedSubject) {
      loadTopics(selectedSubject);
    }
  }, [selectedSubject]);

  useEffect(() => {
    if (selectedTopic) {
      loadMaterials(selectedTopic);
    }
  }, [selectedTopic]);

  async function loadSubjects() {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name');

      if (error) throw error;
      setSubjects(data || []);
    } catch (error) {
      console.error('Error loading subjects:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadTopics(subjectId: string) {
    try {
      const { data, error } = await supabase
        .from('topics')
        .select('*')
        .eq('subject_id', subjectId)
        .order('chapter_number');

      if (error) throw error;
      setTopics(data || []);
      if (data && data.length > 0) {
        setSelectedTopic(data[0].id);
      }
    } catch (error) {
      console.error('Error loading topics:', error);
    }
  }

  async function loadMaterials(topicId: string) {
    try {
      const { data, error } = await supabase
        .from('learning_materials')
        .select('*')
        .eq('topic_id', topicId)
        .order('created_at');

      if (error) throw error;
      setMaterials(data || []);
    } catch (error) {
      console.error('Error loading materials:', error);
    }
  }

  const selectedSubjectData = subjects.find(s => s.id === selectedSubject);
  const selectedTopicData = topics.find(t => t.id === selectedTopic);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Learning Materials</h2>
        <p className="text-gray-600">Study notes, explanations, and examples for each topic</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Subjects</h3>
            <div className="space-y-2">
              {subjects.map((subject) => (
                <button
                  key={subject.id}
                  onClick={() => {
                    setSelectedSubject(subject.id);
                    setSelectedTopic(null);
                    setMaterials([]);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedSubject === subject.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {subject.name}
                </button>
              ))}
            </div>
          </div>

          {topics.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Chapters</h3>
              <div className="space-y-1">
                {topics.map((topic) => (
                  <button
                    key={topic.id}
                    onClick={() => setSelectedTopic(topic.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                      selectedTopic === topic.id
                        ? 'bg-blue-100 text-blue-900 border-l-4 border-blue-600'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <div className="font-medium">Ch {topic.chapter_number}</div>
                    <div className="text-xs line-clamp-2">{topic.name}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-3">
          {!selectedSubject ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Select a subject to view learning materials</p>
            </div>
          ) : !selectedTopic ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Select a chapter to view materials</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <span>{selectedSubjectData?.name}</span>
                  <ChevronRight className="w-4 h-4 mx-1" />
                  <span>Chapter {selectedTopicData?.chapter_number}</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{selectedTopicData?.name}</h3>
                <p className="text-gray-600">{selectedTopicData?.description}</p>
              </div>

              {materials.length === 0 ? (
                <div className="bg-white rounded-lg shadow-md p-12 text-center">
                  <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No learning materials available for this topic yet</p>
                </div>
              ) : (
                materials.map((material) => (
                  <div key={material.id} className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-xl font-semibold text-gray-900">{material.title}</h4>
                      <span className="px-3 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                        {material.material_type}
                      </span>
                    </div>
                    <div className="prose prose-sm max-w-none text-gray-700 whitespace-pre-wrap">
                      {material.content}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
