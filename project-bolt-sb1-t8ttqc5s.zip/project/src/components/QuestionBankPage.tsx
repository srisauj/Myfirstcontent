import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Subject, Topic, Question } from '../lib/database.types';
import { CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';

export function QuestionBankPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [showAnswers, setShowAnswers] = useState<{ [key: string]: boolean }>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubjects();
  }, []);

  useEffect(() => {
    if (selectedSubject) {
      loadTopics(selectedSubject);
      loadQuestions(selectedSubject);
    }
  }, [selectedSubject]);

  useEffect(() => {
    if (selectedSubject) {
      loadQuestions(selectedSubject);
    }
  }, [selectedTopic, selectedDifficulty]);

  async function loadSubjects() {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name');

      if (error) throw error;
      setSubjects(data || []);
    } catch (error) {
      console.error('Error loading subjects:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadTopics(subjectId: string) {
    try {
      const { data, error } = await supabase
        .from('topics')
        .select('*')
        .eq('subject_id', subjectId)
        .order('chapter_number');

      if (error) throw error;
      setTopics(data || []);
    } catch (error) {
      console.error('Error loading topics:', error);
    }
  }

  async function loadQuestions(subjectId: string) {
    try {
      let query = supabase
        .from('questions')
        .select('*, topics!inner(*)')
        .eq('topics.subject_id', subjectId);

      if (selectedTopic !== 'all') {
        query = query.eq('topic_id', selectedTopic);
      }

      if (selectedDifficulty !== 'all') {
        query = query.eq('difficulty', selectedDifficulty);
      }

      const { data, error } = await query.order('created_at');

      if (error) throw error;
      setQuestions(data || []);
    } catch (error) {
      console.error('Error loading questions:', error);
    }
  }

  const toggleAnswer = (questionId: string) => {
    setShowAnswers(prev => ({ ...prev, [questionId]: !prev[questionId] }));
  };

  const selectedSubjectData = subjects.find(s => s.id === selectedSubject);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Question Bank</h2>
        <p className="text-gray-600">Practice questions with detailed explanations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Subject</h3>
            <select
              value={selectedSubject || ''}
              onChange={(e) => {
                setSelectedSubject(e.target.value);
                setSelectedTopic('all');
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Subject</option>
              {subjects.map((subject) => (
                <option key={subject.id} value={subject.id}>
                  {subject.name}
                </option>
              ))}
            </select>
          </div>

          {selectedSubject && (
            <>
              <div className="bg-white rounded-lg shadow-md p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Chapter</h3>
                <select
                  value={selectedTopic}
                  onChange={(e) => setSelectedTopic(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Chapters</option>
                  {topics.map((topic) => (
                    <option key={topic.id} value={topic.id}>
                      Ch {topic.chapter_number}: {topic.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="bg-white rounded-lg shadow-md p-4">
                <h3 className="font-semibold text-gray-900 mb-3">Difficulty</h3>
                <div className="space-y-2">
                  {['all', 'easy', 'medium', 'hard'].map((difficulty) => (
                    <button
                      key={difficulty}
                      onClick={() => setSelectedDifficulty(difficulty)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm capitalize transition-colors ${
                        selectedDifficulty === difficulty
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {difficulty}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        <div className="lg:col-span-3">
          {!selectedSubject ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <p className="text-gray-500">Select a subject to view questions</p>
            </div>
          ) : questions.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <p className="text-gray-500">No questions available for the selected filters</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-white rounded-lg shadow-md p-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">
                    {selectedSubjectData?.name} - {questions.length} Questions
                  </h3>
                </div>
              </div>

              {questions.map((question, index) => (
                <div key={question.id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-sm font-semibold text-gray-500">Q{index + 1}</span>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          question.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                          question.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {question.difficulty}
                        </span>
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                          {question.marks} {question.marks === 1 ? 'mark' : 'marks'}
                        </span>
                      </div>
                      <p className="text-gray-900 mb-4">{question.question_text}</p>

                      {question.question_type === 'mcq' && question.options && (
                        <div className="space-y-2 mb-4">
                          {(question.options as any[]).map((option, idx) => (
                            <div
                              key={idx}
                              className={`p-3 rounded-lg border ${
                                showAnswers[question.id] && option.value === question.correct_answer
                                  ? 'border-green-500 bg-green-50'
                                  : 'border-gray-200 bg-gray-50'
                              }`}
                            >
                              <div className="flex items-center space-x-2">
                                <span className="font-medium text-gray-700">{option.value}.</span>
                                <span className="text-gray-900">{option.text}</span>
                                {showAnswers[question.id] && option.value === question.correct_answer && (
                                  <CheckCircle2 className="w-5 h-5 text-green-600 ml-auto" />
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => toggleAnswer(question.id)}
                    className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium text-sm"
                  >
                    {showAnswers[question.id] ? (
                      <>
                        <ChevronUp className="w-4 h-4" />
                        <span>Hide Answer</span>
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-4 h-4" />
                        <span>Show Answer & Explanation</span>
                      </>
                    )}
                  </button>

                  {showAnswers[question.id] && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-3">
                        <div className="flex items-center space-x-2 mb-2">
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                          <span className="font-semibold text-green-900">Correct Answer:</span>
                        </div>
                        <p className="text-green-900">{question.correct_answer}</p>
                      </div>

                      {question.explanation && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h4 className="font-semibold text-blue-900 mb-2">Explanation:</h4>
                          <p className="text-blue-900 whitespace-pre-wrap">{question.explanation}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
