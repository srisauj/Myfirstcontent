import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Subject } from '../lib/database.types';
import * as Icons from 'lucide-react';

interface SubjectsPageProps {
  onSubjectSelect: (subjectId: string) => void;
}

export function SubjectsPage({ onSubjectSelect }: SubjectsPageProps) {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubjects();
  }, []);

  async function loadSubjects() {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name');

      if (error) throw error;
      setSubjects(data || []);
    } catch (error) {
      console.error('Error loading subjects:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading subjects...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">CBSE Grade 10 Subjects</h2>
        <p className="text-gray-600">Select a subject to explore learning materials, practice questions, and previous year papers</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject) => {
          const IconComponent = (Icons as any)[subject.icon] || Icons.BookOpen;

          return (
            <div
              key={subject.id}
              onClick={() => onSubjectSelect(subject.id)}
              className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all cursor-pointer overflow-hidden group"
            >
              <div
                className="h-32 flex items-center justify-center relative"
                style={{ backgroundColor: subject.color }}
              >
                <IconComponent className="w-16 h-16 text-white opacity-90 group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity" />
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{subject.name}</h3>
                <p className="text-gray-600 text-sm line-clamp-2">{subject.description}</p>

                <div className="mt-4 flex items-center text-sm text-gray-500">
                  <span className="font-medium">Code: {subject.code}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {subjects.length === 0 && (
        <div className="text-center py-12">
          <Icons.BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No subjects available yet</p>
        </div>
      )}
    </div>
  );
}
