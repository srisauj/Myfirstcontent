import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { SubjectsPage } from './components/SubjectsPage';
import { LearningMaterialsPage } from './components/LearningMaterialsPage';
import { QuestionBankPage } from './components/QuestionBankPage';
import { PreviousPapersPage } from './components/PreviousPapersPage';

function App() {
  const [activeTab, setActiveTab] = useState('subjects');

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      <main>
        {activeTab === 'subjects' && (
          <SubjectsPage onSubjectSelect={(subjectId) => setActiveTab('materials')} />
        )}
        {activeTab === 'materials' && <LearningMaterialsPage />}
        {activeTab === 'questions' && <QuestionBankPage />}
        {activeTab === 'papers' && <PreviousPapersPage />}
      </main>
    </div>
  );
}

export default App;
